"""Native JAX figures. Every plotted point is saved beside its generating code.

These algebra/approximation studies are separate from the full data benchmarks.
No R/PyTorch prediction files or rendered figures are loaded.
"""
from pathlib import Path
import time,json
import numpy as np
import jax
import jax.numpy as jnp
import matplotlib.pyplot as plt
from .gaussian import Moments,FullMoments,encode,mfvi_update
from .gaussian_chain import candidate
from .gaussian_reference import chain_reference,ep_site,condition
from . import models,messages,heads,inference,covariance
from .plots import agreement_plot


def save(fig,folder,name):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    fig.tight_layout();fig.savefig(folder/(name+'.png'),dpi=160,bbox_inches='tight');fig.savefig(folder/(name+'.pdf'),bbox_inches='tight')
    return fig


def exact_equivalence(folder='results/semantics'):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);rng=np.random.default_rng(41)
    array=lambda shape:jnp.asarray(rng.normal(size=shape)*.3)
    layers=[];weights=[]
    for d,e in [(3,5),(5,4),(4,3)]:
        layers.append((array((e,d)),array((e,e))+jnp.eye(e),array((e,))))
        w=array((e,e));weights.append(FullMoments(array((e,)),w@w.T+jnp.eye(e)*.2))
    initial=FullMoments(array((3,)),jnp.eye(3)*.3);H=array((2,3));y=array((2,));R=jnp.eye(2)*.1
    forward,activation,weight=candidate(layers,weights,initial,H,y,R)
    ref=chain_reference(*jax.tree_util.tree_map(np.asarray,(layers,weights,initial,H,y,R)))
    fig,axes=plt.subplots(2,2,figsize=(8,7));arrays={};rows=[]
    for i,(qs,label) in enumerate([(activation,'activation'),(weight,'weight')]):
        for k,stat in enumerate(['mean','variance']):
            actual=np.concatenate([np.asarray(q.mean if stat=='mean' else jnp.diag(q.covariance)) for q in qs])
            reference=np.concatenate(ref[label+'_mean'] if stat=='mean' else [np.diag(c) for c in ref[label+'_covariance']])
            agreement_plot(reference,actual,title=f'Gaussian {label} {stat}',xlabel='independent RTS / conditioning',ylabel='pseudo-gradient result',ax=axes[i,k])
            arrays[label+'_'+stat]=actual;arrays['reference_'+label+'_'+stat]=reference
            rows.append({'method':'exact Gaussian','quantity':label+' '+stat,'maximum_error':float(np.max(np.abs(actual-reference)))})
    save(fig,folder,'gaussian_equivalence');plt.close(fig)
    # Explicit cavities and site replacement after EVERY assimilation.
    dim=6;Hs=[rng.normal(size=(2,dim))*.3 for _ in range(6)];ys=[rng.normal(size=2) for _ in Hs];noise=np.eye(2)*.5
    fig,axes=plt.subplots(2,2,figsize=(8,7));traces={}
    for diagonal,label in [(False,'full EP'),(True,'diagonal EP')]:
        P=jnp.eye(dim);h=jnp.zeros(dim);Pr=np.eye(dim);hr=np.zeros(dim)
        sites=[(jnp.zeros((dim,dim)),jnp.zeros(dim)) for _ in Hs];refs=[(np.zeros((dim,dim)),np.zeros(dim)) for _ in Hs]
        av=[];rv=[]
        for sweep in range(3):
            for n,(J,t) in enumerate(zip(Hs,ys)):
                (P,h),sites[n],_=inference.ep_replace((P,h),sites[n],jnp.asarray(J),jnp.asarray(t),jnp.asarray(noise),diagonal)
                Pc,hc=Pr-refs[n][0],hr-refs[n][1];Cc=np.linalg.inv(Pc)
                sn,hn,_,_=ep_site(Cc@hc,Cc,J,t,noise,diagonal);refs[n]=(sn,hn);Pr,hr=Pc+sn,hc+hn
                C=np.linalg.inv(np.asarray(P));Cr=np.linalg.inv(Pr);av.append(np.r_[C@h,np.diag(C)]);rv.append(np.r_[Cr@hr,np.diag(Cr)])
        a=np.asarray(av);r=np.asarray(rv);traces[label.replace(' ','_')]=a;traces['reference_'+label.replace(' ','_')]=r
        row=0 if diagonal is False else 1
        for k,stat in enumerate(['mean','variance']):
            sl=slice(0,dim) if k==0 else slice(dim,None)
            agreement_plot(r[:,sl],a[:,sl],title=label+' '+stat,xlabel='independent explicit-site EP',ylabel='pseudo-gradient EP',ax=axes[row,k])
        rows.append({'method':label,'quantity':'all iterates','maximum_error':float(np.max(np.abs(a-r)))})
    save(fig,folder,'ep_equivalence');plt.close(fig)
    # CAVI comparison uses the learned candidate state, not the analytic optimum.
    X=jnp.asarray(rng.normal(size=(12,dim))*.3);target=jnp.asarray(rng.normal(size=12));prior=Moments(jnp.zeros(dim),jnp.ones(dim))
    q=Moments(jnp.asarray(rng.normal(size=dim)),jnp.ones(dim)*.8);Pr=np.eye(dim)+np.asarray(X.T@X);hr=np.asarray(X.T@target)
    mr=np.asarray(q.mean).copy();av=[];rv=[];gaps=[]
    likelihood=lambda q:-.5*jnp.sum((target-X@q.mean)**2+(X*X)@q.variance)
    for sweep in range(20):
        for i in range(dim):
            g=jax.grad(likelihood)(q);proposal=mfvi_update(q,encode(q,g),prior)
            q=Moments(q.mean.at[i].set(proposal.mean[i]),q.variance.at[i].set(proposal.variance[i]))
            mr[i]=(hr[i]-Pr[i]@mr+Pr[i,i]*mr[i])/Pr[i,i]
            av.append(np.r_[q.mean,q.variance]);vr=np.asarray(av[-2][dim:] if len(av)>1 else np.ones(dim)*.8).copy();vr[i]=1/Pr[i,i];rv.append(np.r_[mr,vr])
            gaps.append(np.linalg.norm(Pr@np.asarray(q.mean)-hr))
    a=np.array(av);r=np.array(rv);fig,axes=plt.subplots(1,2,figsize=(8,3.8))
    for k,stat in enumerate(['mean','variance']):
        sl=slice(0,dim) if k==0 else slice(dim,None)
        agreement_plot(r[:,sl],a[:,sl],title='MFVI '+stat,xlabel='coordinate-ascent VI',ylabel='canonical pseudo-gradient update',ax=axes[k])
    save(fig,folder,'mfvi_equivalence');plt.close(fig);traces.update(mfvi=a,reference_mfvi=r,mfvi_mean_residual=gaps)
    rows.append({'method':'diagonal MFVI','quantity':'all iterates','maximum_error':float(np.max(np.abs(a-r)))})
    np.savez_compressed(folder/'equivalence.npz',**arrays,**traces)
    (folder/'equivalence.json').write_text(json.dumps(rows,indent=2));return rows


def benchmark(f,*args,repeats=5):
    compiled=jax.jit(f);begin=time.perf_counter();out=compiled(*args);jax.block_until_ready(out);compilation=time.perf_counter()-begin
    times=[]
    for _ in range(repeats):
        begin=time.perf_counter();out=compiled(*args);jax.block_until_ready(out);times.append(time.perf_counter()-begin)
    return out,float(np.median(times)),compilation


def approximation_study(folder='results/semantics',samples=16384):
    """Common Gaussian weight belief; same regression objective and coordinates.

    MC references average complete networks. EP differentiates log(mean f),
    never mean(log f). Reference sensitivity is with respect to (m,v), then
    encoded in the SAME natural moment coordinates as the approximation.
    """
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    model=models.mlp(inputs=4,width=12,classes=2,dtype=jnp.float64);q=model.snapshot()
    q={n:Moments(p.mean,jnp.ones_like(p.variance)*.015) for n,p in q.items()}
    x=jnp.asarray(np.random.default_rng(9).normal(size=(3,4)));y=jnp.array([0,1,0]);key=jax.random.PRNGKey(42)
    noises={n:jax.random.normal(k,(samples,)+p.mean.shape,dtype=p.mean.dtype) for (n,p),k in zip(sorted(q.items()),jax.random.split(key,len(q)))}
    def mc(q):
        w={n:p.mean+jnp.sqrt(p.variance)*noises[n] for n,p in q.items()}
        z=jax.vmap(lambda w:messages.point_forward(model.nodes,w,x)[0])(w)
        return z
    z,mc_seconds,mc_compile=benchmark(mc,q,repeats=3)
    reference=FullMoments(z.mean(0),jnp.einsum('sbi,sbj->bij',z-z.mean(0),z-z.mean(0))/samples)
    reference_grad={};reference_signal={}
    for method in ['mfvi','ep']:
        g=jax.jit(jax.grad(lambda q:heads.categorical_objective(mc(q),y,method)))(q)
        reference_grad[method]=g;reference_signal[method]={n:encode(q[n],g[n]) for n in q}
    schemes=[('diagonal',None),('shared rank 4',4),('shared rank 16',16),('shared rank 64',64)]
    rows=[];arrays={'reference_mean':reference.mean,'reference_covariance':reference.covariance};saved=[]
    for name,rank in schemes:
        if rank is None:
            f=lambda q:messages.forward(model.nodes,q,Moments(x,jnp.zeros_like(x)))[0]['readout']
        else:f=lambda q,rank=rank:covariance.shared_records(model.nodes,q,x,jax.random.PRNGKey(91),rank)[0]['readout']
        out,seconds,compile_seconds=benchmark(f,q)
        stem=name.replace(' ','_');arrays[stem+'_mean']=out.mean;arrays[stem+'_covariance']=out.covariance
        row={'scheme':name,'forward_seconds':seconds,'compile_seconds':compile_seconds,
             'mean_relative_error':float(jnp.linalg.norm(out.mean-reference.mean)/jnp.linalg.norm(reference.mean)),
             'covariance_relative_error':float(jnp.linalg.norm(out.covariance-reference.covariance)/jnp.linalg.norm(reference.covariance))}
        for method in ['mfvi','ep']:
            if rank is None:gfun=lambda q:inference.moment_likelihood(model.nodes,q,x,y,method=method)[1]
            else:gfun=lambda q:covariance.shared_likelihood(model.nodes,q,x,y,jax.random.PRNGKey(91),rank,method=method)[1]
            grad,back_seconds,bc=benchmark(gfun,q,repeats=3)
            actual={n:encode(q[n],grad[n]) for n in q};reference_s=reference_signal[method]
            for stat in ['mean','second']:
                a=np.concatenate([np.asarray(getattr(actual[n],stat)).ravel() for n in sorted(q)])
                r=np.concatenate([np.asarray(getattr(reference_s[n],stat)).ravel() for n in sorted(q)])
                arrays[stem+'_'+method+'_'+stat]=a;arrays['reference_'+method+'_'+stat]=r
                row[method+'_'+stat+'_relative_error']=float(np.linalg.norm(a-r)/np.linalg.norm(r))
            row[method+'_forward_backward_seconds']=back_seconds
        rows.append(row);saved.append((name,out))
    fig,axes=plt.subplots(2,len(schemes),figsize=(12,6))
    for i,(name,out) in enumerate(saved):
        agreement_plot(reference.mean,out.mean,title=name,xlabel='MC output mean',ylabel='moment output mean',ax=axes[0,i])
        agreement_plot(jnp.diagonal(reference.covariance,axis1=-2,axis2=-1),jnp.diagonal(out.covariance,axis1=-2,axis2=-1),title=name,xlabel='MC output variance',ylabel='moment output variance',ax=axes[1,i])
    save(fig,folder,'forward_approximation');plt.close(fig)
    for method in ['mfvi','ep']:
        fig,axes=plt.subplots(2,len(schemes),figsize=(12,6))
        for i,(name,_) in enumerate(schemes):
            for k,stat in enumerate(['mean','second']):
                agreement_plot(arrays['reference_'+method+'_'+stat],arrays[name.replace(' ','_')+'_'+method+'_'+stat],title=name,xlabel='MC '+stat+' moment signal',ylabel='approximate signal',ax=axes[k,i])
        save(fig,folder,method+'_backward_approximation');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(9,3.8))
    for row in rows:
        axes[0].scatter(row['forward_seconds']*1000,row['covariance_relative_error'],label=row['scheme'])
        axes[1].scatter(row['mfvi_forward_backward_seconds']*1000,row['mfvi_second_relative_error'],label=row['scheme'])
    for ax,title in zip(axes,['Forward covariance','MFVI raw-second signal']):ax.set(xlabel='execution milliseconds',ylabel='relative error against MC',title=title);ax.legend(fontsize=8);ax.grid(alpha=.2)
    save(fig,folder,'approximation_cost');plt.close(fig)
    receipt={'samples':samples,'mc_forward_seconds':mc_seconds,'mc_compile_seconds':mc_compile,'rows':rows,'note':'Untrained nonlinear fixture; no classification-performance claim.'}
    np.savez_compressed(folder/'approximation.npz',**jax.tree_util.tree_map(np.asarray,arrays));(folder/'approximation.json').write_text(json.dumps(receipt,indent=2))
    return receipt

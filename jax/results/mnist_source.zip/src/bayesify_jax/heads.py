"""EP log-normalizer and MFVI expected log likelihood are separate objectives."""
import math
import jax
import jax.numpy as jnp
from jax.scipy.special import logsumexp
from .gaussian import encode,FullMoments


def gaussian_head(q,y,noise,method='ep'):
    if method=='ep':
        S=q.variance+noise;e=y-q.mean
        value=-.5*jnp.sum(jnp.log(2*jnp.pi*S)+e*e/S)
        gradient=(e/S,.5*(e*e/S**2-1/S))
    elif method=='mfvi':
        e=y-q.mean
        value=-.5*jnp.sum(jnp.log(2*jnp.pi*noise)+(e*e+q.variance)/noise)
        gradient=(e/noise,jnp.full_like(q.variance,-.5)/noise)
    else:raise ValueError(method)
    return value,encode(q,gradient)


def categorical_nodes(q):
    if isinstance(q,FullMoments):
        k=q.mean.shape[-1];D=jnp.concatenate((jnp.eye(k-1,dtype=q.mean.dtype),-jnp.ones((k-1,1),dtype=q.mean.dtype)),1)
        m=q.mean@D.T;C=jnp.einsum("ij,bjk,lk->bil",D,q.covariance,D)
        L=jnp.linalg.cholesky(C);delta=jnp.sqrt(k-1)*jnp.moveaxis(L,-1,0)
        nodes=jnp.concatenate((m[None]+delta,m[None]-delta),0)
        return jnp.pad(nodes,((0,0),(0,0),(0,1)))
    k=q.mean.shape[-1];offset=jnp.sqrt(k*q.variance)[None,...]*jnp.eye(k,dtype=q.mean.dtype)[:,None,:]
    return jnp.concatenate((q.mean[None]+offset,q.mean[None]-offset),0)


def categorical_objective(nodes,labels,method='mfvi',power=1.):
    logp=jax.nn.log_softmax(nodes,-1)
    selected=jnp.take_along_axis(logp,labels[None,:,None],-1)[...,0]
    if method=='mfvi':return selected.mean(0).sum()
    if method=='ep':return ((logsumexp(power*selected,axis=0)-math.log(nodes.shape[0]))/power).sum()
    raise ValueError(method)


def categorical_head(q,labels,method='mfvi',power=1.):
    f=lambda q:categorical_objective(categorical_nodes(q),labels,method,power)
    value,g=jax.value_and_grad(f)(q)
    return value,encode(q,g)


def probabilities(q):
    return jax.nn.softmax(categorical_nodes(q),-1).mean(0)


def full_covariance_probabilities(mean,covariance):
    # Softmax is invariant to a common shift; integrate C-1 contrasts.
    k=mean.shape[-1];D=jnp.concatenate((jnp.eye(k-1,dtype=mean.dtype),-jnp.ones((k-1,1),dtype=mean.dtype)),1)
    a=mean@D.T;C=jnp.einsum('ij,bjk,lk->bil',D,covariance,D)
    # PSD eigenfactor supports singular contrasts without artificial jitter.
    values,vectors=jnp.linalg.eigh(C);L=vectors*jnp.sqrt(jnp.maximum(values,0))[:,None,:]
    delta=jnp.sqrt(k-1)*jnp.moveaxis(L,-1,0)
    nodes=jnp.concatenate((a[None]+delta,a[None]-delta),0)
    return jax.nn.softmax(jnp.pad(nodes,((0,0),(0,0),(0,1))),-1).mean(0)

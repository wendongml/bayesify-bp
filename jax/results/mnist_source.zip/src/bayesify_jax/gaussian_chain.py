"""Exact affine-chain pseudo-backpropagation, independent of the reference."""
import jax
import jax.numpy as jnp
from .gaussian import FullMoments,encode_full,decode_full


def evidence(q,H,y,R):
    S=H@q.covariance@H.T+R;e=y-H@q.mean
    return -.5*(len(y)*jnp.log(2*jnp.pi)+jnp.linalg.slogdet(S)[1]+e@jnp.linalg.solve(S,e))


def candidate(layers,weights,initial,H,y,R):
    states=[initial]
    for (A,B,c),q in zip(layers,weights):
        x=states[-1];states.append(FullMoments(A@x.mean+B@q.mean+c,A@x.covariance@A.T+B@q.covariance@B.T))
    head=jax.grad(evidence)(states[-1],H,y,R);signal=encode_full(states[-1],head)
    activation=[None]*len(states);weight=[None]*len(weights);activation[-1]=signal
    for i in reversed(range(len(layers))):
        A,B,c=layers[i]
        def local(x,w):return FullMoments(A@x.mean+B@w.mean+c,A@x.covariance@A.T+B@w.covariance@B.T)
        _,pull=jax.vjp(local,states[i],weights[i]);gx,gw=pull(FullMoments(*decode_full(states[i+1],signal)))
        weight[i]=encode_full(weights[i],gw);signal=encode_full(states[i],gx);activation[i]=signal
    install=lambda q,d:FullMoments(q.mean+d[0],q.covariance+d[1]-jnp.outer(q.mean,d[0])-jnp.outer(d[0],q.mean)-jnp.outer(d[0],d[0]))
    return states,[install(q,d) for q,d in zip(states,activation)],[install(q,d) for q,d in zip(weights,weight)]

import jax,gc
from bayesify_jax.training import protocol,train
for arch in ['mlp','lenet']:
 for method in ['ordinary','sampled_mfvi','moment_mfvi','sampled_ep','moment_ep']:
  print('START',arch,method,flush=True)
  train(protocol(arch,method,41))
  jax.clear_caches();gc.collect()
print('COMPLETE',flush=True)
